const mongoose = require('mongoose');


const todoSchema = mongoose.Schema({
    todo_name: {type: String},
    status: {type: String},
    todo_type: {type: String},
}, {
    timestamps: true,
}
)
module.exports = mongoose.model('Todo', todoSchema);

