const Users = require('../model/userSchema');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const createUser = async(req, res) => {

    const email = req.body.email;
    const fullname = req.body.fullname;
    const password = req.body.password;

    if (!email)
        return res.json({ msg: "email address can't be empty" });
    if (!fullname)
        return res.json({ msg: "Fullname can't be empty" });
    if (!password)
        return res.json({ msg: "password can't be empty" });
    
    const userExist = await Users.findOne({ email: email });
    if (userExist)
        return res.json({ msg: "user with such email already exist" });

    const hash = await bcrypt.hashSync(password, 10);

    const User = new Users({ email, fullname, password:hash });

    try {
        await User.save()
        return res.status(200).json({ user: User, msg: "Account created successfully" });
    } catch (error) {
        return res.send(error); 
    }
    
}


const loginUser = async (req, res) => {
    const email = req.body.email;
    const password = req.body.password;

    if (!email)
        return res.status(400).json({ msg: "empty email field" })
    if (!password)
        return res.status(400).json({ msg: "empty password field" });
    const user = await Users.findOne({ email: email });
    if (!user)
        return res.status(400).json({ msg: "User with email address not found" })
    const verufyPass = await bcrypt.compare(password, user.password);
    if (!verufyPass)
        return res.status(400).json({ msg: "Incorrect password! try again" });
    
    return res.status(200).json({
        msg: "you have successfully sign in",
        _id: user._id,
        name: user.fullname,
        email: user.email,
        token: generateToken(user._id)
    });
}


//GENERATE JWT FOR AUTH

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  })
}


module.exports = {createUser, loginUser}