
const Todo = require('../model/todoModel')


const allTodo = async (req, res) => {

    const todo = await Todo.find();
    try {
        return res.status(200).json(todo);
    } catch (error) {
        return res.send(error);
    }
    
}


const addTodo = async (req, res) => {
    
    const todo_name = req.body.todo_name;
    const status = 'running';
    const todo_type = req.body.todo_type;

    if (!todo_name)
        return res.json({ msg: "provide todo name" });
    if (!todo_type)
        return res.json({ msg: "Please select todo type" });

    const todo = new Todo({
        todo_name, status, todo_type
    });
    try {
        await todo.save()
        //console.log(todo)
        return res.status(200).json({ todo: todo, msg: "successfully added todo" });
    } catch (error) {
        console.log(error);
    }
    
}


const updateTodo = async (req, res) => {

    const id = req.params.id;
    const todo = await Todo.findById(id);
    todo.status = 'done';
    try {
        await todo.save()
        return res.status(200).json({ todo:todo, msg:"Todo set to done" });
    } catch (error) {
        return res.send(error);
    }
    
}



const deleteTodo = async (req, res) => {
    const id = req.params.id;
    try {
        await Todo.findByIdAndRemove(id).exec();
        return res.json({ msg: "Todo successfully Removed" });
    } catch (error) {
        return res.send(error);
    }
}


const latestTodo = async (req, res) => {
    try {
        const latest = await Todo.find({}).sort('created_at').limit(4);
        return res.json(latest);
    } catch (error) {
        return res.send(error.message)
    }
}



module.exports = {allTodo, addTodo, updateTodo, deleteTodo, latestTodo}