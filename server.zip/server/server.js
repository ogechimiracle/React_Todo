const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();
const DB = require ('./config/db');

const port = process.env.PORT;
const appname = process.env.APP_NAME;


const app = express();
app.use(bodyParser.json({ limit:"20mb", extended: true }));
app.use(bodyParser.urlencoded({ limit: "20mb", extended: true }));


app.use(cors());
DB();

app.use('/api/todo', require('./routes/todoRoutes'));
app.use('/api/user', require('./routes/userRoutes'));


app.get('/', (req, res) => res.send('server started running'));


app.listen(port, () => console.log(`${appname} running on port ${port}`));


