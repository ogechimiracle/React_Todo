

const router = require('express').Router();

const { allTodo, addTodo, updateTodo, deleteTodo, latestTodo } = require('../controller/todoController');


router.get('/', allTodo)
router.get('/latest', latestTodo)
router.post('/', addTodo)
router.put('/update/:id', updateTodo)
router.delete('/delete/:id', deleteTodo)


module.exports = router;